package com.example.planet;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView2;
    EditText editText;
    String Planets []={"Mercury","Mars","Venus","Earth","Uranus","Neptune","Saturn","Jupiter"};
    double Mass []={0.0553,0.107,	0.815	,1	,14.5,	17.1,95.2	,318};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void calculate(View v){
        editText=(EditText)findViewById(R.id.editText);
        textView2=(TextView)findViewById(R.id.textView);
        for(int i=0;i<Mass.length;i++){
            textView2.setText(textView2.getText().toString()+Planets[i]+" = "+(Integer.valueOf(editText.getText().toString())*Mass[i])+"\n");
        }
    }

    public void goToSecond(View v) {
        Intent in=new Intent(MainActivity.this,Main2Activity.class);
        startActivity(in);
    }
}
