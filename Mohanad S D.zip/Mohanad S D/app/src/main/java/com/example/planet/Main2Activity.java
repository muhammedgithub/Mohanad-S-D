package com.example.planet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    TextView textView2;
    EditText editText,editText2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button btn=(Button)findViewById(R.id.button3);
        editText=(EditText) findViewById(R.id.editText3);
        editText2=(EditText) findViewById(R.id.editText2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int w=(Integer.valueOf(editText.getText().toString())),h=(Integer.valueOf(editText2.getText().toString()));
                double result=(double)w/(double)(h*h);
                textView2=(TextView)findViewById(R.id.textView2);
                textView2.setText(result+"");
            }
        });
    }



}
